using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CROPDEAL.Models;
using CROPDEAL.Models.DTO;
using Microsoft.AspNetCore.Mvc;

namespace CROPDEAL.Interfaces
{
    public interface IAuth
    {
        Task<bool> Register(User user);
        Task<User> Login(LoginRequest request);
        Task<User> GetUserByEmailAsync(string email);
        Task<IEnumerable<UserDTO>> GetAllUsers();
        Task<UserDTO?> GetUserById(string userId);
        Task<bool> UpdateUser(string userId, UserDTO user);
        Task<bool> DeleteUser(string userId);
        Task LogToDatabase(string level, string message, DateTime now);
    }
}