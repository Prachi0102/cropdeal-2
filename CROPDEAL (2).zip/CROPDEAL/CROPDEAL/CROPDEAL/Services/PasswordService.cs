using Microsoft.AspNetCore.Identity;

namespace CROPDEAL.Services
{
    public class PasswordService
    {
        private readonly PasswordHasher<object> _passwordHasher = new();  

        // Hashes a plain passowrd into hashed.
        public string HashPassword(string password)
        {
            return _passwordHasher.HashPassword(null, password);  // returns hashed version of password in string format.
        }

        // Verifies whether the provided password matches the stored (hashed) password. 
        public bool VerifyPassword(string hashedPassword, string providedPassword)
        {
            return _passwordHasher.VerifyHashedPassword(null, hashedPassword, providedPassword) == PasswordVerificationResult.Success;
        }
    }
}