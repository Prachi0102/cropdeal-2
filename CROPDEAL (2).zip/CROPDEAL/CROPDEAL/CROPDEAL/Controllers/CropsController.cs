using CROPDEAL.Interfaces;
using CROPDEAL.Repository;
using CROPDEAL.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;
using CROPDEAL.Models.DTO;

namespace CROPDEAL.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class CropsController : ControllerBase
    {
        private readonly ICrops crop;
        public CropsController(ICrops _crop)
        {
            crop = _crop;
        }

        [HttpGet("GetAllCrops")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllCrops()
        {
            try
            {
                var Crops = await crop.GetAllCrops();
                if (Crops == null)
                {
                    return NoContent();
                }
                return Ok(Crops);
            }
            catch (Exception e)
            {
                await crop.LogToDatabase("Error", $"Exception Occurred: {e.Message}", DateTime.Now);
                return BadRequest(e.Message);
            }
        }

        [HttpGet("GetCropById")]
        [Authorize(Roles = "Dealer,Farmer")]
        public async Task<IActionResult> GetCropById(string cropId)
        {
            try
            {
                var Crops = await crop.GetCropById(cropId);
                if (Crops == null)
                {
                    return NoContent();
                }
                return Ok(Crops);
            }
            catch (Exception e)
            {
                await crop.LogToDatabase("Error", $"Exception Occurred: {e.Message}", DateTime.Now);
                return BadRequest(e.Message);
            }
        }

        [HttpGet("GetCropsByUserId/{userId}")]
        [Authorize(Roles = "Admin,Farmer")] 
        public async Task<IActionResult> GetOrdersByUserId(string userId)
        {
            try
            {
                var crops = await crop.GetCropsByUserId(userId);
                if (crops == null || !crops.Any())
                {
                    return NoContent(); // Return 204 if no data found
                }
                return Ok(crops); // Return orders if found
            }
            catch (Exception ex)
            {
                await crop.LogToDatabase("Error", $"Exception Occurred: {ex.Message}", DateTime.Now);
                return BadRequest(ex.Message);
            }
        }


        [HttpPost("AddCrop")]
        [Authorize(Roles = "Farmer")]
        public async Task<IActionResult> AddCrop([FromBody] CropDTO u)
        {
            try
            {
                if (!await crop.AddCrop(u))
                {
                    return BadRequest("Wrong Request");
                }
                return Ok("Crop Added");
            }

            catch (Exception e)
            {
                await crop.LogToDatabase("Error", $"Exception Occurred: {e.Message}", DateTime.Now);
                return BadRequest(e.Message);
            }
        }

        [HttpPut("UpdateCrop")]
        [Authorize(Roles = "Farmer")]
        public async Task<IActionResult> UpdateCrop([FromBody] CropDTO u)
        {
            try
            {
                if (!await crop.UpdateCrop(u))
                {
                    return BadRequest("Wrong Request");
                }
                return Ok("Crop Updated");
            }
            catch (Exception e)
            {
                await crop.LogToDatabase("Error", $"Exception Occurred: {e.Message}", DateTime.Now);
                return BadRequest(e.Message);
            }
        }
        [HttpDelete("DeleteCrop/{cropId}")]
        [Authorize(Roles = "Admin,Farmer")]
        public async Task<IActionResult> DeleteCrop(string cropId)
        {
            try
            {
                if (!await crop.DeleteCrop(cropId))
                {
                    return BadRequest("Wrong Request");
                }
                return Ok("Crop Deleted");
            }

            catch (Exception e)
            {
                await crop.LogToDatabase("Error", $"Exception Occurred: {e.Message}", DateTime.Now);
                return BadRequest(e.Message);
            }
        }
    }
}